C323/Spring 2022
Lab26
4/14/22 2:33 PM
Aspen Lara 
Brandon Wening
Drew Mesker


For the first half of the comment, we're going to use a split view controller for the menu. Also,
we decided to use the MessageUI framework for Assignemnt1 #6 framework. 
