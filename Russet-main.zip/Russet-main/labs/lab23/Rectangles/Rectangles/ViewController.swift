//
//  ViewController.swift
//  Rectangles
//
//  Created by Wening, Brandon Matthew on 4/1/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

