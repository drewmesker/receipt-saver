//
//  RectanglesView.swift
//  Rectangles
//
//  Created by Wening, Brandon Matthew on 4/1/22.
//


import UIKit

class RectanglesView: UIView {
    
    var globalCenter: CGPoint = CGPoint(x: 50, y: 50)
    
    override func draw(_ rect: CGRect){
        let myFirstPath = UIBezierPath()
        var i:CGFloat=0
        while(i<35){
        myFirstPath.addArc(withCenter: globalCenter,
                           radius: 50-i,
                           startAngle: 0,
                           endAngle: 6.28,
                           clockwise: true)
        myFirstPath.stroke()
        myFirstPath.move(to: CGPoint(x: globalCenter.x+50-i-7, y: globalCenter.y))
        i+=7
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let myEvent = event {
            let firstTouch = myEvent.allTouches!.first
            let startingPoint = firstTouch?.location(in: self)
            self.globalCenter = startingPoint!
            self.setNeedsDisplay()
        }
    }
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
