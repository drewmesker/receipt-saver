//
//  CameraVIewController.swift
//  ReceiptSaver
//  Brandon Wening - bwening
//  Aspen Lara - asplara
//  Drew Mesker - dmesker
// With help from iOS Academy on Framework Setup

import AVFoundation
import Foundation
import UIKit
import MapKit

class CameraViewController : UIViewController
{
    var NameField : String?
    var PriceField : Double?
    var longitude : Double?
    var latitude : Double?
    
    
    var camSession: AVCaptureSession?
    let output = AVCapturePhotoOutput()
    let previewLayer = AVCaptureVideoPreviewLayer()
    private let cameraButton: UIButton = {
        let button = UIButton(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
        button.layer.cornerRadius = 50
        button.layer.borderWidth = 10
        button.layer.borderColor = UIColor.white.cgColor
        return button
    }()
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        view.backgroundColor = .black
        view.layer.addSublayer(previewLayer)
        view.addSubview(cameraButton)
        let locationManager = CLLocationManager()
        locationManager.requestWhenInUseAuthorization()
        checkCamera()
        cameraButton.addTarget(self, action: #selector(TakePhoto), for: .touchUpInside)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer.frame = view.bounds
        cameraButton.center = CGPoint(x: view.frame.size.width/2,
                                      y: view.frame.size.height - 120)
        
    }
    
    private func checkCamera()
    {
        switch AVCaptureDevice.authorizationStatus(for: .video)
        {
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in guard granted else
            {
                return
            }
                DispatchQueue.main.async
                {
                    self?.setUpCamera()
                }
                
        }
        case .restricted:
            break
        case .denied:
            break
        case .authorized:
            setUpCamera()
        @unknown default:
            break
        }
    }
    
    private func setUpCamera()
    {
        let session = AVCaptureSession()
        if let device = AVCaptureDevice.default(for: .video)
        {
            do
            {
                let input = try AVCaptureDeviceInput(device: device)
                if session.canAddInput(input)
                {
                    session.addInput(input)
                }
                
                if session.canAddOutput(output)
                {
                    session.addOutput(output)
                }
                
                previewLayer.videoGravity = .resizeAspectFill
                previewLayer.session = session
                
                session.startRunning()
                self.camSession = session
            }
            catch
            {
                print(error)
            }
        }
    }
    
    @objc private func TakePhoto()
    {
        output.capturePhoto(with: AVCapturePhotoSettings(), delegate: self)
    }
    
    
    
}

extension CameraViewController: AVCapturePhotoCaptureDelegate {
 func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?  )
    {
        var appDelegate: AppDelegate?
        
        var myModel: RecieptsDataModel?
        

        appDelegate = UIApplication.shared.delegate as? AppDelegate
        myModel = appDelegate?.myRecieptsData
        //SAVE PHOTO TO STORAGE
        let photoData = photo.fileDataRepresentation()
        do{
                let fm = FileManager.default
                let docsurl = try fm.url(for:.documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            let picFile = docsurl.appendingPathComponent("photo\(myModel!.myData.count+1).jpg")
            try photoData?.write(to: picFile)
                print(picFile)
            
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)

            let infoViewController = storyBoard.instantiateViewController(withIdentifier: "Info View") as! InfoViewController
            infoViewController.imageLink = picFile
            self.present(infoViewController, animated:true, completion: nil)
        }catch{
            print(error)
        }
        
        
    }
}
