//
//  RecieptsDataModel.swift
//  ReceiptSaver
//  Brandon Wening - bwening
//  Aspen Lara - asplara
//  Drew Mesker - dmesker

import Foundation
import CoreLocation
import MapKit

class RecieptsDataModel: NSObject, Codable {
    override var description : String {return "RecieptsDataModel"}
        
    override init(){
        super.init()
    }
    
    var myData: [ Reciept ] = [
        Reciept(aImage: URL(string: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/ReceiptSwiss.jpg/170px-ReceiptSwiss.jpg")!, aLocation: "Kilroy's on Kirkwood", aLatitude: 39.166340, aLongitude: -86.528030, aDate: Date(), aPrice: 53.43)
             ]
    
    func addReciept(pImage: URL,pLocation: String, pLatitude: Double, pLongitude: Double, pDate: Date, pPrice: Double){
        myData.append(Reciept(aImage: pImage, aLocation: pLocation, aLatitude: pLatitude, aLongitude: pLongitude, aDate: pDate, aPrice: pPrice))
    }
}

class Reciept: NSObject, Codable{
    var theImage: URL
    var theLocation: String
    var theLatitude: Double
    var theLongitude: Double
    var theDate: Date
    var thePrice: Double
    
    override var description : String {return "Reciept Object"}

    init (aImage: URL,aLocation: String, aLatitude: Double, aLongitude: Double, aDate: Date, aPrice: Double){
        self.theImage = aImage
        self.theLocation = aLocation
        self.theLatitude = aLatitude
        self.theLongitude = aLongitude
        self.theDate = aDate
        self.thePrice = aPrice
        
        super.init()
    }
    
    func getCoordinates() -> CLLocationCoordinate2D{
        return CLLocationCoordinate2D(latitude: self.theLatitude, longitude: self.theLongitude)
    }
}
