//
//  RecieptTableViewCell.swift
//  ReceiptSaver
//  Brandon Wening - bwening
//  Aspen Lara - asplara
//  Drew Mesker - dmesker

import Foundation
import UIKit

class RecieptTableViewCell: UITableViewCell {
    @IBOutlet weak var recieptImage: UIImageView!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var costLabel: UILabel!
    
    static let identifier = "recieptCell"
    
    static func nib() -> UINib {
        return UINib(nibName: "recieptCell", bundle: nil)
    }
 
    
    @IBOutlet weak var emailButton: UIButton!
    
    
 }
