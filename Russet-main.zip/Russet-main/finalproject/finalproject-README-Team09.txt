C323 / Spring 2022, Final Project
5/03 2:17 PM
Brandon Wening bwening
Drew Mesker dmesker
Aspen Lara asplara
Team09
Russet

ReceiptSaver


Code Responsibilities: Brandon: Map functionality & Model & persistent storage
						Drew: Camera functionality & persistent storage & infoViewController
						Aspen: Email functionality & Setting up Views
						
Instructions:  1. The app opens to the Camera View and asks to use your location. First click allow
			  while using app. Then allow the app to access the camera.
			  
			  *In the camera view you can take photos of receipts. Once you take a photo, you can input
			  the location name and price to be saved with the image to the table view.
			  
			  2. Next click the menu button at the top. this will take you to a view
			  with menu options. Click List View to see your saved Receipts.
			  
			  *Inside list view you will see your receipts saved as cells in a table.
			  you can see the location name of where the receipt photo was taken, the date, and price.
			  You also can click the email button where you have the option of emailing your receipt to
			  yourself or someone else. 
			  
			  3. Finally, click map view to see a map with the location of where you took photos of
			  each of your receipts. If you click on the marker for any of your receipts, you will see
			  an annotation with the location name, date, price, and image. if you click the image, the 
			  receiptlist table view pops up and shows you that specific saved receipt. 
			  			
				
				
Xcode Environment: Version- 13.2.1
					tested on Iphone X latest IOS 


Required Functionalities: Model View Controller architectural pattern used
						  Buttons: camera button in camera view
						  			email button in tableview
						  text input: infoviewcontroller has inputs for location and price
						  text output: date in receiptlist table view
						  Map output: map annotation placed onto map view 
						  
						  3 Views: map view
						  		 camera View 
						  		 Receiptlist table View
						  
						  Split view container view controller can be seen in main &
						  contains views & navigation controllers.
						  
						  Persistent storage in AppDelegate
						  
						  App uses MapKit & UIImage & Core Location & Message UI(wasn't shown in class)
						  -MapKit and Corelocation are used in MapViewController
						  -UIImage used in CameraViewController
						  - Message UI used in ReceiptListTableViewController for the Email button
Changes: 
		The design isn't exactly the same as from the original wireframe, and mainly we chose 
		not to include a search functionality. The search functionality would have taken more time
		to implement so we decided not to include it. This change was present in all of the previous
		assignments except for assignment 1. You can see that we didn't include the search icon in 
		the ReceiptListTableviewcontroller.
		
		
		
		
		