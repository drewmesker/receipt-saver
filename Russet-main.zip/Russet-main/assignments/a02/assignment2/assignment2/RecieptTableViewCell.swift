//
//  RecieptTableViewCell.swift
//  assignment2
//
//  Created by Wening, Brandon Matthew on 4/16/22.
//

import Foundation
import UIKit

class RecieptTableViewCell: UITableViewCell {
    @IBOutlet weak var recieptImage: UIImageView!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var costLabel: UILabel!
}
