//
//  RecieptsDataModel.swift
//  assignment2
//
//  Created by Wening, Brandon Matthew on 4/16/22.
//

import Foundation

class RecieptsDataModel {
    var myData: [ Reciept ] = [
        Reciept(aImage: URL(string: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/ReceiptSwiss.jpg/170px-ReceiptSwiss.jpg")!, aLocation: "Kilroy's on Kirkwood",aDate: Date(), aPrice: 53.43)
             ]
}

class Reciept{
    var theImage: URL
    var theLocation: String
    var theDate: Date
    var thePrice: Double
    
    init (aImage: URL,aLocation: String, aDate: Date, aPrice: Double){
        self.theImage = aImage
        self.theLocation = aLocation
        self.theDate = aDate
        self.thePrice = aPrice
    }
}
