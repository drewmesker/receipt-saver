Drew Mesker - dmesker
Aspen Lara - asplara
Brandon Wening - bwening


The idea for our app started when a friend of mine noticed on his credit card statement that a bill from a restaurant was way higher than he thought it should have been. 
He contacted his card company, but they could not do anything about it since he did not have his receipt. 
He started to take pictures of every receipt he got, but his camera roll quickly became flooded with pictures that he didnt want to see, but only if he needed them. 
For our final project, our app will be a storage and database app for pictures, specifically receipts. 
A user will take a picture of their receipt and the app will store the time and geolocation of the picture taken and store them within the app.
The photos taken could be downloaded but will not download automatically to clean up local storage in camera roll.
A list view of all receipts taken will be shown showcasing a small icon, location, time, and optional user entered toal cost on receipt.
A map view will also be available to keep a record of all photos recorded. The app will function within a split view controller to switch between views. 
Additionally, an updated view for our app will include an option to share via email. This framework will allow users to share a picture all within the app.
We are still working on coming up with creative name for our app. 
