//
//  InfoViewController.swift
//  RecieptSaver
//
//  Created by Mesker, Drew W on 4/28/22.
//

import Foundation
import CoreLocation
import CoreLocationUI
import UIKit


class InfoViewController : UIViewController, CLLocationManagerDelegate
{
    
    @IBOutlet weak var NameTextField: UITextField!
    @IBOutlet weak var PriceTextFIeld: UITextField!
    
    var imageLink : URL?
    
    var latitude : Double?
    var longitude : Double?
    var NameText : String?
    var PriceText : Double?
    
    
    
    
    @IBAction func SubmitButtonPress(_ sender: Any)
    {
        
        NameText = NameTextField.text
        PriceText = Double(PriceTextFIeld.text!)
        
        let LocationManager = CLLocationManager()
        LocationManager.delegate = self
        
        LocationManager.requestWhenInUseAuthorization()
        LocationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        LocationManager.startUpdatingLocation()
        
        var appDelegate: AppDelegate?
        
        var myModel: RecieptsDataModel?
        
        appDelegate = UIApplication.shared.delegate as? AppDelegate
        myModel = appDelegate?.myRecieptsData
        
        latitude = LocationManager.location?.coordinate.latitude
        longitude = LocationManager.location?.coordinate.longitude
        
        //ADD RECIEPT TO MODEL HERE
        myModel!.addReciept(pImage: imageLink!, pLocation: NameText!, pLatitude: latitude!, pLongitude: longitude!, pDate: Date(), pPrice: PriceText!)
        
        // SAVE MODEL AFTER RECIEPT IS ADDED
        do{
                let fm = FileManager.default
                let docsurl = try fm.url(for:.documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
                let modelArray = myModel!
                let modelFile = docsurl.appendingPathComponent("model.plist")
                let plister = PropertyListEncoder()
                plister.outputFormat = .xml
                try plister.encode(modelArray).write(to: modelFile, options: .atomic)
                print(modelFile)
        }catch{
                print(error)
        }
        
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func CancelButtonPress(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
   
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
}
