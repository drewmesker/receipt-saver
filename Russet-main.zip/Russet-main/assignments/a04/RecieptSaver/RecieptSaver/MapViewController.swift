//
//  MapViewController.swift
//  assignment4
//
//  Created by Mesker, Drew W on 4/15/22.
//

import UIKit
import MapKit

class MapViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate
{
    
    let locationManager = CLLocationManager()
    
    var appDelegate: AppDelegate?
    
    var latitude : Double?
    var longitude : Double?
    var userName : String?
    var userPrice : String?
    
    @IBOutlet weak var myMap: MKMapView!
    
    var myModel: RecieptsDataModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myMap.delegate = self
        
        self.locationManager.requestWhenInUseAuthorization()
        
        if(CLLocationManager.locationServicesEnabled()){
            self.locationManager.delegate = self
            self.locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            self.locationManager.startUpdatingLocation()
        }
        let startingLocation = self.locationManager.location ?? CLLocation(latitude: 39.166340, longitude: -86.528030)
        myMap.setRegion(MKCoordinateRegion(center: startingLocation.coordinate, latitudinalMeters: 1000000, longitudinalMeters: 1000000), animated: true)
        
        self.appDelegate = UIApplication.shared.delegate as? AppDelegate
        self.myModel = self.appDelegate?.myRecieptsData
        createAnnotations()
        
        // Do any additional setup after loading the view.
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        guard !annotation.isKind(of: MKUserLocation.self) else {
            return nil
        }
        
        var annotationView: MKMarkerAnnotationView
        if let dequeuedView = mapView.dequeueReusableAnnotationView(
              withIdentifier: "identifier") as? MKMarkerAnnotationView {
              dequeuedView.annotation = annotation
              annotationView = dequeuedView
            } else {
              annotationView = MKMarkerAnnotationView(
                annotation: annotation,
                reuseIdentifier: "identifier")
                annotationView.canShowCallout = true
                annotationView.calloutOffset = CGPoint(x: -5, y: 5)
                if let annotation = annotation as? RecieptAnnotation{
                    if let receiptData = try? Data(contentsOf: annotation.image){
                        let recieptButton = UIButton(frame: CGRect(
                            origin: CGPoint.zero,
                            size: CGSize(width: 48, height: 48)))
                        recieptButton.setBackgroundImage(UIImage(data:receiptData), for: .normal)
                        annotationView.rightCalloutAccessoryView = recieptButton
                    }
                }
            }
        return annotationView
    }
    
    func mapView(
      _ mapView: MKMapView,
      annotationView view: MKAnnotationView,
      calloutAccessoryControlTapped control: UIControl) {
      guard let reciept = view.annotation as? RecieptAnnotation else {
        return
      }
          //MOVE TO RECIEPT LOCATION ON TABLE VIEW CONTROLLER
          let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)

          let tableViewController = storyBoard.instantiateViewController(withIdentifier: "List View") as! RecieptListTableViewController
          tableViewController.tableView.scrollToRow(at: IndexPath(row: reciept.id, section: 0), at: .top, animated: true)
          self.present(tableViewController, animated:true, completion:nil)
    }
    
    func createAnnotations(){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        var counter = -1
        for reciepts in myModel!.myData {
            counter+=1
            let subTitle = dateFormatter.string(from: reciepts.theDate) + "  $" + String(format: "%.2f", reciepts.thePrice)
            let annotation = RecieptAnnotation(coordinates: reciepts.getCoordinates(), aTitle: reciepts.theLocation, aSubtitle: subTitle, aURL: reciepts.theImage, aID:counter)
            myMap.addAnnotation(annotation)
        }
    }


}

class RecieptAnnotation: NSObject, MKAnnotation {
    
    @objc dynamic var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    var image: URL
    var id: Int
    
    init(coordinates:CLLocationCoordinate2D, aTitle:String, aSubtitle:String, aURL:URL, aID: Int){
        self.coordinate = coordinates
        self.title = aTitle
        self.subtitle = aSubtitle
        self.image = aURL
        self.id = aID
        super.init()
    }
}
