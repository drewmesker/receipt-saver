//
//  RecieptTableViewCell.swift
//  assignment4
//
//  Created by Wening, Brandon Matthew on 4/16/22.
//

import Foundation
import UIKit

class RecieptTableViewCell: UITableViewCell {
    @IBOutlet weak var recieptImage: UIImageView!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var costLabel: UILabel!
    
    static let identifier = "recieptCell"
    
    static func nib() -> UINib {
        return UINib(nibName: "recieptCell", bundle: nil)
    }
 
    
    @IBOutlet weak var emailButton: UIButton!
    
    
 }
