//
//  RecieptTableViewCell.swift
//  assignment3
//
//  Created by Wening, Brandon Matthew on 4/16/22.
//

import Foundation
import UIKit

protocol MyTableViewCellDelegate: AnyObject {
    func didTapButton()
}

class RecieptTableViewCell: UITableViewCell {
    weak var delegate: MyTableViewCellDelegate?
    @IBOutlet weak var recieptImage: UIImageView!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var costLabel: UILabel!
    
    static let identifier = "recieptCell"
    
    static func nib() -> UINib {
        return UINib(nibName: "recieptCell", bundle: nil)
    }
 
    
    @IBOutlet weak var emailButton: UIButton!
    @IBAction func didTapButton() {
        delegate?.didTapButton()
    }
    
    
 }
