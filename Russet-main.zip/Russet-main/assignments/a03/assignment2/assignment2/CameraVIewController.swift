//
//  CameraVIewController.swift
//  assignment2
//
//  Created by Mesker, Drew W on 4/24/22.
// With help from iOS Academy on Framework Setup

import AVFoundation
import Foundation
import UIKit

class CameraViewController : UIViewController
{
    var camSession: AVCaptureSession?
    let output = AVCapturePhotoOutput()
    let previewLayer = AVCaptureVideoPreviewLayer()
    private let cameraButton: UIButton = {
        let button = UIButton(frame: CGRect(x: 0, y: 0, width: 75, height: 75))
        button.layer.cornerRadius = 50
        button.layer.borderWidth = 10
        button.layer.borderColor = UIColor.white.cgColor
        return button
    }()
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        view.backgroundColor = .black
        view.layer.addSublayer(previewLayer)
        view.addSubview(cameraButton)
        checkCamera()
        cameraButton.addTarget(self, action: #selector(TakePhoto), for: .touchUpInside)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer.frame = view.bounds
        cameraButton.center = CGPoint(x: view.frame.size.width/2,
                                      y: view.frame.size.height - 120)
        
    }
    
    private func checkCamera()
    {
        switch AVCaptureDevice.authorizationStatus(for: .video)
        {
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in guard granted else
            {
                return
            }
                DispatchQueue.main.async
                {
                    self?.setUpCamera()
                }
                
        }
        case .restricted:
            break
        case .denied:
            break
        case .authorized:
            setUpCamera()
        @unknown default:
            break
        }
    }
    
    private func setUpCamera()
    {
        let session = AVCaptureSession()
        if let device = AVCaptureDevice.default(for: .video)
        {
            do
            {
                let input = try AVCaptureDeviceInput(device: device)
                if session.canAddInput(input)
                {
                    session.addInput(input)
                }
                
                if session.canAddOutput(output)
                {
                    session.addOutput(output)
                }
                
                previewLayer.videoGravity = .resizeAspectFill
                previewLayer.session = session
                
                session.startRunning()
                self.camSession = session
            }
            catch
            {
                print(error)
            }
        }
    }
    
    @objc private func TakePhoto()
    {
         output.capturePhoto(with: AVCapturePhotoSettings(), delegate: self)
    }
    
    
    
}

extension CameraViewController: AVCapturePhotoCaptureDelegate {
 func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?  )
    {
        var appDelegate: AppDelegate?
        
        var myModel: RecieptsDataModel?

        appDelegate = UIApplication.shared.delegate as? AppDelegate
        myModel = appDelegate?.myRecieptsData

        let photoData = photo.fileDataRepresentation()
        do{
                let fm = FileManager.default
                let docsurl = try fm.url(for:.documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            let picFile = docsurl.appendingPathComponent("photo\(myModel!.myData.count+1).jpg")
            try photoData?.write(to: picFile)
                print(picFile)
            //ADD TO MODEL HERE
            //NEED TO ACCURATELY ADD LOCATION TITLE, COORDINATES, AND PRICE STILL
            myModel!.addReciept(pImage: picFile, pLocation: "Kilroy's on Kirkwood - Test", pLatitude: 37.166340, pLongitude: -84.528030, pDate: Date(), pPrice: 53.43)
                }catch{
                    print(error)
                }    }
}
