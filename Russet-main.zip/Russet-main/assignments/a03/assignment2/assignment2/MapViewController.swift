//
//  MapViewController.swift
//  assignment3
//
//  Created by Mesker, Drew W on 4/15/22.
//

import UIKit
import MapKit

class MapViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    
    let locationManager = CLLocationManager()
    
    var appDelegate: AppDelegate?
        
    @IBOutlet weak var myMap: MKMapView!
    
    var myModel: RecieptsDataModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myMap.delegate = self
        
        self.locationManager.requestWhenInUseAuthorization()
        
        if(CLLocationManager.locationServicesEnabled()){
            self.locationManager.delegate = self
            self.locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            self.locationManager.startUpdatingLocation()
        }
        self.appDelegate = UIApplication.shared.delegate as? AppDelegate
        self.myModel = self.appDelegate?.myRecieptsData
        createAnnotations()
        
        // Do any additional setup after loading the view.
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        guard !annotation.isKind(of: MKUserLocation.self) else {
            // Make a fast exit if the annotation is the `MKUserLocation`, as it's not an annotation view we wish to customize.
            return nil
        }
        
        var annotationView: MKMarkerAnnotationView
        if let dequeuedView = mapView.dequeueReusableAnnotationView(
              withIdentifier: "identifier") as? MKMarkerAnnotationView {
              dequeuedView.annotation = annotation
              annotationView = dequeuedView
            } else {
              annotationView = MKMarkerAnnotationView(
                annotation: annotation,
                reuseIdentifier: "identifier")
                annotationView.canShowCallout = true
                annotationView.calloutOffset = CGPoint(x: -5, y: 5)
                annotationView.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
            }
        return annotationView
    }
        
    func createAnnotations(){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        for reciepts in myModel!.myData {
            let annotation = RecieptAnnotation(coordinates: reciepts.getCoordinates(), aTitle: reciepts.theLocation, aSubtitle: dateFormatter.string(from: reciepts.theDate))
            myMap.addAnnotation(annotation)
        }
    }


}

class RecieptAnnotation: NSObject, MKAnnotation {
    
    @objc dynamic var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    
    init(coordinates:CLLocationCoordinate2D, aTitle:String, aSubtitle:String){
        self.coordinate = coordinates
        self.title = aTitle
        self.subtitle = aSubtitle
        super.init()
    }
}
